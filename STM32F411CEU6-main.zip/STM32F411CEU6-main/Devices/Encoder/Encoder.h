#ifndef ENCODER_H_
#define ENCODER_H_


void Encoder_Init(TIM_TypeDef *timer);

uint16_t EncOder_Read(TIM_TypeDef *timer);




#endif 
